function Get-PufferSearchPreview {
    <#
    #>

    param (

    )
}