function Get-PufferMailPurge {
    <#
    #>

    param (

    )
}