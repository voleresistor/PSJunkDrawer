function Get-PufferMailSearch {
    <#
    #>

    param (

    )
}