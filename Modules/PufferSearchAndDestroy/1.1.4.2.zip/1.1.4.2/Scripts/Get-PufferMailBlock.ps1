function Get-PufferMailBlock {
    <#
    #>

    param (

    )
}