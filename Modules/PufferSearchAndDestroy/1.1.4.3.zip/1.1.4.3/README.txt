PufferSearchAndDestroy
v1.0.0.0

Authors:
Andrew Ogden - andrew.ogden@puffer.com
Matt Silcox @ Catapult Systems

Requirements:
PowerShell 5.0+

Installation:
1. Copy the root folder (PufferSearchAndDestroy) to your Documents\WindowsPowerShell\Modules folder.
2. The module should be available to the next PS 5.0 session you start. You can check with Get-Module -Name PufferSearchAndDestroy

Docs:
PufferSearchAndDestroy.docx povided for convenience. All data is alo available using PowerShell built in help.
e.g. Get-Help -Name Start-PufferSearchAndDestroy